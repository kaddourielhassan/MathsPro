/* eslint-disable */
'use client';

import Navigation from '@/components/Navigation';
import { useStore } from '@/lib/store';
import { Brain, UserPlus, Play, Users, Trophy } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { motion } from 'motion/react';

export default function Home() {
  const { profiles, setCurrentProfile, addProfile, setRole } = useStore();
  const router = useRouter();
  const [newProfileName, setNewProfileName] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  const handleSelectProfile = (id: string) => {
    setCurrentProfile(id);
    setRole('student');
    router.push('/dashboard');
  };

  const handleCreateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (newProfileName.trim()) {
      // Basic animal avatars
      const avatars = ['🦊', '🐼', '🦁', '🐸', '🐯', '🐙'];
      const randomAvatar = avatars[Math.floor(Math.random() * avatars.length)];
      addProfile(newProfileName.trim(), randomAvatar);
      // Wait for store to update then redirect (the store setCurrentProfile automatically, so we just redirect)
      router.push('/dashboard');
    }
  };

  const handleTeacherLogin = () => {
    setRole('teacher');
    setCurrentProfile(null);
    router.push('/teacher');
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navigation />
      
      <main className="flex-1 max-w-4xl w-full mx-auto p-4 py-12 flex flex-col items-center">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-6 mb-16"
        >
          <div className="inline-flex items-center justify-center p-4 bg-orange-100 dark:bg-orange-900/40 rounded-2xl text-orange-600 dark:text-orange-400 mb-4 border-2 border-orange-200">
            <Brain size={48} />
          </div>
          <h1 className="text-4xl md:text-6xl font-black tracking-tight text-slate-900 dark:text-white">
            LE CERVEAU EST UN <span className="text-orange-600 dark:text-orange-400 px-2">MUSCLE</span> 💪
          </h1>
          <p className="text-xl font-medium text-slate-500 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed">
            Prêt(e) à booster tes capacités ? Ici, pas de stress : que tu sois là pour t'entraîner à ton rythme ou relever des défis, tu vas progresser efficacement.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-xs font-black uppercase tracking-widest text-slate-600 dark:text-slate-300 pt-4">
            <div className="flex items-center gap-2 bg-white dark:bg-slate-800 px-5 py-3 rounded-xl border-2 border-slate-100 shadow-sm">
              <span className="text-red-500 text-lg">🚫</span> Calculatrice interdite
            </div>
            <div className="flex items-center gap-2 bg-white dark:bg-slate-800 px-5 py-3 rounded-xl border-2 border-slate-100 shadow-sm">
              <Trophy className="text-orange-500" size={20} /> Gagne de l'XP
            </div>
            <div className="flex items-center gap-2 bg-white dark:bg-slate-800 px-5 py-3 rounded-xl border-2 border-slate-100 shadow-sm">
              <Play className="text-emerald-500" size={20} /> Mode Dual inclus
            </div>
          </div>
        </motion.div>

        <div className="w-full max-w-3xl glass-panel p-8 mb-8 border-t-8 border-orange-200 dark:border-orange-900">
          <h2 className="text-xs font-black uppercase text-slate-400 mb-8 tracking-widest text-center">Choisis ton profil</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {profiles.map(p => (
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                key={p.id}
                onClick={() => handleSelectProfile(p.id)}
                className="flex flex-col items-center justify-center p-6 bg-white dark:bg-slate-800 rounded-3xl shadow-sm hover:shadow-md transition gap-3 border-2 border-slate-100 dark:border-slate-700 hover:border-orange-400"
              >
                <div className="text-5xl mb-2">{p.avatar}</div>
                <div className="font-black text-xl">{p.name}</div>
                <div className="text-xs font-bold uppercase tracking-widest text-emerald-500 bg-emerald-50 dark:bg-emerald-900/40 px-3 py-1 rounded-full">Niveau {p.level}</div>
              </motion.button>
            ))}

            {!isCreating ? (
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsCreating(true)}
                className="flex flex-col items-center justify-center p-6 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border-2 border-dashed border-slate-300 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition gap-3 hover:border-orange-300"
              >
                <UserPlus size={32} />
                <span className="text-sm font-black uppercase tracking-widest mt-2">Nouveau Profil</span>
              </motion.button>
            ) : (
              <form onSubmit={handleCreateProfile} className="flex flex-col items-center justify-center p-6 bg-white dark:bg-slate-800 rounded-3xl shadow-sm gap-4 col-span-1 border-2 border-orange-200 sm:col-span-2 md:col-span-1">
                <input
                  type="text"
                  required
                  autoFocus
                  placeholder="Ton prénom..."
                  value={newProfileName}
                  onChange={e => setNewProfileName(e.target.value)}
                  className="w-full text-center px-4 py-3 rounded-xl bg-slate-100 dark:bg-slate-900 font-bold text-slate-800 dark:text-white border-2 border-transparent focus:border-orange-400 outline-none transition uppercase tracking-wider"
                />
                <div className="flex gap-2 w-full">
                  <button type="button" onClick={() => setIsCreating(false)} className="flex-1 px-3 py-3 rounded-xl bg-slate-100 dark:bg-slate-700 text-xs font-black uppercase tracking-widest text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-600 transition">
                    Annuler
                  </button>
                  <button type="submit" className="flex-1 px-3 py-3 rounded-xl bg-emerald-500 text-white text-xs font-black uppercase tracking-widest hover:bg-emerald-600 transition shadow-lg border-b-4 border-emerald-700 active:border-b-0 active:translate-y-1">
                    Go!
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

        <div className="mt-8 text-center mb-12">
           <button onClick={handleTeacherLogin} className="text-xs font-black uppercase tracking-widest text-slate-400 hover:text-orange-500 transition flex items-center justify-center gap-2 mx-auto">
             <Users size={16} /> Accès Professeur / Vie Scolaire
           </button>
        </div>

      </main>

      <footer className="py-6 text-center text-sm text-slate-500 dark:text-slate-400">
        🌸 Cette application web est conçue par M. El KADDOURI à l'aide de l'IA - 2026 🌸
      </footer>
    </div>
  );
}
