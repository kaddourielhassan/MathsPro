/* eslint-disable */
'use client';

import { useStore } from '@/lib/store';
import { MODULE_INFO } from '@/lib/data';
import Navigation from '@/components/Navigation';
import { useRouter } from 'next/navigation';
import { useParams } from 'next/navigation';
import { useState } from 'react';
import type { ModuleId, Level } from '@/lib/mathEngine';
import { BookOpen, Zap, Swords, ChevronLeft, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import { motion } from 'motion/react';

export default function ModuleSelect() {
  const { currentProfileId } = useStore();
  const { id } = useParams() as { id: ModuleId };
  const router = useRouter();

  if (!currentProfileId) {
    if (typeof window !== 'undefined') router.push('/');
    return null;
  }

  const info = MODULE_INFO[id];
  if (!info) return <div>Module introuvable</div>;

  return (
    <div className="flex flex-col min-h-screen">
      <Navigation />
      
      <main className="flex-1 max-w-3xl w-full mx-auto p-4 sm:p-6 py-8">
        <Link href="/dashboard" className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-widest text-slate-400 hover:text-orange-500 transition mb-6">
          <ChevronLeft size={16} /> Retour au tableau de bord
        </Link>
        
        <div className="text-center mb-12">
           <div className="inline-flex items-center justify-center p-6 rounded-3xl bg-orange-50 dark:bg-slate-800/50 text-6xl mb-6 border-2 border-orange-100 dark:border-slate-700 shadow-sm">
             {info.icon}
           </div>
           <h1 className="text-5xl font-black mb-4 tracking-tight text-slate-900 dark:text-white uppercase">{info.title}</h1>
           <p className="text-lg font-medium text-slate-500 dark:text-slate-400 max-w-xl mx-auto">{info.description}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Entraînement */}
          <motion.div 
            whileHover={{ y: -4 }}
            className="glass-panel p-8 rounded-3xl flex flex-col h-full cursor-pointer hover:border-blue-400 dark:hover:border-blue-600 transition"
            onClick={() => router.push(`/module/${id}/learn`)}
          >
            <div className="w-16 h-16 bg-blue-500 text-white rounded-2xl flex items-center justify-center shadow-lg border-b-4 border-blue-700 mb-6">
              <BookOpen size={32} />
            </div>
            <h2 className="text-2xl font-black mb-3 text-slate-900 dark:text-white uppercase tracking-tight">Entraînement</h2>
            <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-8 flex-1 leading-relaxed">
              Fiche méthode, aide guidée et temps illimité. Idéal pour comprendre et assimiler.
            </p>
            <div className="flex items-center justify-between text-blue-500 font-black uppercase tracking-widest text-sm mt-auto">
              <span>S'entraîner</span>
              <ArrowRight size={20} />
            </div>
          </motion.div>

          {/* Test Chronométré */}
          <motion.div 
            whileHover={{ y: -4 }}
            className="glass-panel p-8 rounded-3xl flex flex-col h-full cursor-pointer hover:border-amber-400 dark:hover:border-amber-600 transition"
            onClick={() => router.push(`/module/${id}/test`)}
          >
            <div className="w-16 h-16 bg-amber-500 text-white rounded-2xl flex items-center justify-center shadow-lg border-b-4 border-amber-700 mb-6">
              <Zap size={32} className="fill-current" />
            </div>
            <h2 className="text-2xl font-black mb-3 text-slate-900 dark:text-white uppercase tracking-tight">Test Chronométré</h2>
            <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-8 flex-1 leading-relaxed">
              Série de 10 questions. Pas d'aide, chronomètre actif. Gagne de l'XP en validant !
            </p>
            <div className="flex items-center justify-between text-amber-500 font-black uppercase tracking-widest text-sm mt-auto">
              <span>Lancer le test</span>
              <ArrowRight size={20} />
            </div>
          </motion.div>
          
          {/* Duel */}
          <motion.div 
            whileHover={{ y: -4 }}
            className={`glass-panel p-8 rounded-3xl flex flex-col h-full cursor-pointer hover:border-rose-400 dark:hover:border-rose-600 transition ${id === 'fractions' ? '' : 'md:col-span-2 md:w-2/3 md:mx-auto'}`}
            onClick={() => router.push(`/module/${id}/duel`)}
          >
            <div className="w-16 h-16 bg-rose-500 text-white rounded-2xl flex items-center justify-center shadow-lg border-b-4 border-rose-700 mb-6 mx-auto">
              <Swords size={32} />
            </div>
            <h2 className="text-2xl font-black mb-3 text-slate-900 dark:text-white uppercase tracking-tight text-center">Duel Local</h2>
            <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-8 flex-1 text-center leading-relaxed">
              Affronte un camarade sur le même écran. Le premier à 5 points gagne !
            </p>
            <div className="flex items-center justify-between text-rose-500 font-black uppercase tracking-widest text-sm mt-auto">
              <span>Défier</span>
              <ArrowRight size={20} />
            </div>
          </motion.div>

          {id === 'fractions' && (
            <motion.div 
              whileHover={{ y: -4 }}
              className="glass-panel p-8 rounded-3xl flex flex-col h-full cursor-pointer hover:border-emerald-400 dark:hover:border-emerald-600 transition"
              onClick={() => router.push(`/module/${id}/visual`)}
            >
              <div className="w-16 h-16 bg-emerald-500 text-white rounded-2xl flex items-center justify-center shadow-lg border-b-4 border-emerald-700 mb-6 mx-auto">
                <div className="text-3xl">🟩</div>
              </div>
              <h2 className="text-2xl font-black mb-3 text-slate-900 dark:text-white uppercase tracking-tight text-center">Atelier Visuel</h2>
              <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-8 flex-1 text-center leading-relaxed">
                Manipule visuellement les fractions en coloriant des parts. Découvre la simplification pas à pas !
              </p>
              <div className="flex items-center justify-between text-emerald-500 font-black uppercase tracking-widest text-sm mt-auto">
                <span>Dessiner</span>
                <ArrowRight size={20} />
              </div>
            </motion.div>
          )}

        </div>
      </main>
    </div>
  );
}
