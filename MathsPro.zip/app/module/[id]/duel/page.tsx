/* eslint-disable */
'use client';

import { useState } from 'react';
import Navigation from '@/components/Navigation';
import { generateQuestion, getOptions, type Question, type ModuleId } from '@/lib/mathEngine';
import { useParams, useRouter } from 'next/navigation';
import { ChevronLeft, Trophy } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import confetti from 'canvas-confetti';
import Link from 'next/link';

export default function DuelMode() {
  const { id } = useParams() as { id: ModuleId };
  const router = useRouter();

  const [question, setQuestion] = useState<Question | null>(null);
  const [options, setOptions] = useState<string[]>([]);
  const [score1, setScore1] = useState(0);
  const [score2, setScore2] = useState(0);
  const [winner, setWinner] = useState<number | null>(null);
  const [lock, setLock] = useState(false);

  const newRound = () => {
    const q = generateQuestion(id, 'confirmé'); // base duel level
    setQuestion(q);
    setOptions(getOptions(q));
    setLock(false);
  };

  const startGame = () => {
    setScore1(0);
    setScore2(0);
    setWinner(null);
    newRound();
  };

  const handleAnswer = (player: 1 | 2, ans: string) => {
    if (lock) return;
    setLock(true);
    
    if (ans === String(question!.answer)) {
      // Point given
      if (player === 1) {
        const next = score1 + 1;
        setScore1(next);
        if (next >= 5) return finish(1);
      } else {
        const next = score2 + 1;
        setScore2(next);
        if (next >= 5) return finish(2);
      }
    } else {
      // Penalty? For now, no penalty, just wait a second and next round
    }
    
    setTimeout(newRound, 1500);
  };

  const finish = (w: number) => {
    setWinner(w);
    confetti({ particleCount: 200, spread: 90, zIndex: 100 });
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-900 absolute inset-0 overflow-hidden text-slate-100 font-sans">
      
      {!question && !winner ? (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center relative z-10 bg-slate-900">
          <Link href={`/module/${id}`} className="absolute top-8 left-8 inline-flex items-center gap-2 text-xs font-black uppercase tracking-widest text-slate-500 hover:text-white transition bg-slate-800 px-4 py-2 rounded-full border border-slate-700">
             <ChevronLeft size={16} /> Quitter
          </Link>
          <div className="text-8xl mb-8">⚔️</div>
          <h1 className="text-5xl font-black mb-6 uppercase tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-rose-400">Mode Duel Local</h1>
          <p className="text-xl font-medium text-slate-400 mb-12 max-w-md leading-relaxed">Le premier joueur à 5 points gagne la couronne. Positionnez-vous de chaque côté de l'écran.</p>
          <button 
            onClick={startGame}
            className="px-12 py-6 bg-slate-100 text-slate-900 rounded-full font-black text-3xl hover:bg-white transition scale-110 shadow-[0_0_40px_rgba(255,255,255,0.3)] active:scale-100 uppercase tracking-widest border-b-8 border-slate-300 active:border-b-0 active:mt-8"
          >
            FIGHT !
          </button>
        </div>
      ) : winner ? (
         <div className="flex-1 flex flex-col items-center justify-center relative z-10 bg-slate-900">
           <Trophy size={120} className="text-amber-400 mb-8 drop-shadow-[0_0_30px_rgba(251,191,36,0.5)]" />
           <h2 className="text-6xl font-black mb-12 text-white uppercase tracking-tighter">
             JOUEUR <span className={winner === 1 ? 'text-blue-400' : 'text-rose-400'}>{winner}</span> GAGNE !
           </h2>
           <div className="flex gap-6">
              <button onClick={() => router.push(`/module/${id}`)} className="px-8 py-4 border-2 border-slate-700 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-800 transition text-slate-300">Retour</button>
              <button onClick={startGame} className="px-8 py-4 bg-emerald-500 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-emerald-400 transition shadow-lg border-b-4 border-emerald-700 active:border-b-0 active:translate-y-1">Revanche</button>
           </div>
         </div>
      ) : question ? (
        <div className="flex-1 flex flex-col md:flex-row relative">
          {/* Middle dividing line inside flex row (on desktop) or flex col (on mobile) */}
          <div className="absolute top-1/2 left-0 right-0 h-4 bg-slate-950 -translate-y-1/2 md:hidden z-20 shadow-2xl border-y border-slate-800" />
          <div className="absolute left-1/2 top-0 bottom-0 w-4 bg-slate-950 -translate-x-1/2 hidden md:block z-20 shadow-2xl border-x border-slate-800" />
          
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-56 h-56 bg-slate-950 rounded-full border-[12px] border-slate-800 z-30 flex items-center justify-center flex-col shadow-[0_0_50px_rgba(0,0,0,0.5)]">
              <div className="text-6xl lg:text-8xl font-mono font-black tracking-tighter text-white drop-shadow-lg">{question.text}</div>
          </div>
          
          {/* Player 1 (Top on mobile, Left on desktop) */}
          <div className="flex-1 flex flex-col justify-center items-center p-8 bg-blue-600 relative overflow-hidden">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMiIgZmlsbD0icmdiYSgwLCAwLCAwLCAwLjEpIi8+PC9zdmc+')] opacity-50"></div>
            <div className="text-[150px] font-black opacity-[0.05] absolute top-[-20px] left-[-20px] pointer-events-none tracking-tighter">P1</div>
            <div className="text-5xl font-black text-white mb-auto mt-4 px-8 py-3 bg-blue-700 rounded-3xl shadow-inner border-y border-blue-500 z-10">{score1} <span className="text-2xl opacity-70">pts</span></div>
            
            <div className="grid grid-cols-2 gap-6 w-full max-w-md mt-auto mb-12 rotate-180 md:rotate-0 z-10">
              {options.map(opt => (
                <button
                  key={opt}
                  onClick={() => handleAnswer(1, opt)}
                  className="p-8 bg-blue-800 text-white hover:bg-blue-500 border-4 border-blue-900 rounded-3xl text-4xl font-black transition active:scale-95 shadow-xl border-b-8 active:border-b-4 active:translate-y-1"
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>

          {/* Player 2 (Bottom on mobile, Right on desktop) */}
          <div className="flex-1 flex flex-col justify-center items-center p-8 bg-rose-600 relative overflow-hidden">
             <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMiIgZmlsbD0icmdiYSgwLCAwLCAwLCAwLjEpIi8+PC9zdmc+')] opacity-50"></div>
            <div className="text-[150px] font-black opacity-[0.05] absolute bottom-[-40px] right-[-20px] pointer-events-none tracking-tighter">P2</div>
            <div className="grid grid-cols-2 gap-6 w-full max-w-md mt-12 mb-auto z-10">
              {options.map(opt => (
                <button
                  key={opt}
                  onClick={() => handleAnswer(2, opt)}
                  className="p-8 bg-rose-800 text-white hover:bg-rose-500 border-4 border-rose-900 rounded-3xl text-4xl font-black transition active:scale-95 shadow-xl border-b-8 active:border-b-4 active:translate-y-1"
                >
                  {opt}
                </button>
              ))}
            </div>
            
            <div className="text-5xl font-black text-white mt-auto mb-4 px-8 py-3 bg-rose-700 rounded-3xl shadow-inner border-y border-rose-500 z-10">{score2} <span className="text-2xl opacity-70">pts</span></div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
