/* eslint-disable */
'use client';

import { useStore } from '@/lib/store';
import { MODULE_INFO } from '@/lib/data';
import Navigation from '@/components/Navigation';
import { generateQuestion, getOptions, type Question, type ModuleId } from '@/lib/mathEngine';
import { getExplanation } from '@/lib/gemini';
import { useState, useEffect, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ChevronLeft, HelpCircle, BrainCircuit, ArrowRight, CheckCircle2, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Link from 'next/link';
import confetti from 'canvas-confetti';

export default function LearnMode() {
  const { currentProfileId } = useStore();
  const { id } = useParams() as { id: ModuleId };
  const router = useRouter();

  const [showMethod, setShowMethod] = useState(true);
  const [question, setQuestion] = useState<Question | null>(null);
  const [options, setOptions] = useState<string[]>([]);
  const [score, setScore] = useState(0);
  const [asked, setAsked] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [aiExplanation, setAiExplanation] = useState<string | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [hintStep, setHintStep] = useState(0);

  const initQuestion = useCallback(() => {
    // Determine level based on current asked count to make it progressive
    const level = asked < 3 ? 'débutant' : asked < 7 ? 'confirmé' : 'expert';
    const q = generateQuestion(id, level);
    setQuestion(q);
    setOptions(getOptions(q));
    setSelectedAnswer(null);
    setIsCorrect(null);
    setAiExplanation(null);
    setShowHint(false);
    setHintStep(0);
  }, [id, asked]);

  // ... rest of the file ...

  const handleNextHint = () => {
    setHintStep(prev => prev + 1);
  };

  useEffect(() => {
    if (!showMethod) {
      initQuestion();
    }
  }, [showMethod, initQuestion]);

  if (!currentProfileId) {
    if (typeof window !== 'undefined') router.push('/');
    return null;
  }

  const handleAnswer = async (ans: string) => {
    if (selectedAnswer) return; // Prevent double click
    
    setSelectedAnswer(ans);
    const correct = ans === String(question!.answer);
    setIsCorrect(correct);
    setAsked(prev => prev + 1);
    
    if (correct) {
      setScore(prev => prev + 1);
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.8 },
        colors: ['#4f46e5', '#10b981']
      });
    } else {
      setLoadingAi(true);
      const explanation = await getExplanation(question!.text, ans, String(question!.answer));
      setAiExplanation(explanation);
      setLoadingAi(false);
    }
  };

  const methodContent = () => {
    if (id === 'fractions') {
      return (
        <div className="space-y-4 text-left">
          <h3 className="font-bold text-lg">🧠 Simplifier une fraction par petits pas</h3>
          <p>Règle d'Or : Diviser le haut ET le bas par le même nombre ne change pas la valeur.</p>
          <ul className="space-y-2 list-disc pl-5">
            <li><strong>PAIRS ?</strong> → Diviser par 2, recommencer</li>
            <li><strong>Finissent par 5 ou 0 ?</strong> → Diviser par 5 ou 10</li>
            <li><strong>Table de 3 ?</strong> → Additionner les chiffres</li>
            <li><strong>Tables connues ?</strong> → Chercher 4, 6, 7, 8, 9</li>
          </ul>
          <p className="font-bold text-indigo-600 dark:text-indigo-400 italic">"Je cherche un petit nombre qui marche en haut ET en bas, je divise les deux, je recommence !"</p>
        </div>
      );
    }
    return (
      <div className="space-y-4 text-left">
        <h3 className="font-bold text-lg">Rappels pour : {MODULE_INFO[id]?.title}</h3>
        <p>Prends ton temps, c'est l'entraînement. N'hésite pas à utiliser le bouton d'aide si tu es bloqué. L'important n'est pas la vitesse, mais la précision.</p>
      </div>
    );
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navigation />
      
      <main className="flex-1 max-w-2xl w-full mx-auto p-4 sm:p-6 flex flex-col justify-center">
        <Link href={`/module/${id}`} className="absolute top-24 left-4 md:left-8 inline-flex items-center gap-2 text-xs font-black uppercase tracking-widest text-slate-400 hover:text-orange-500 transition z-10">
          <ChevronLeft size={16} /> Quitter
        </Link>
        
        <AnimatePresence mode="wait">
          {showMethod ? (
            <motion.div 
              key="method"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass-panel p-8 sm:p-12 rounded-3xl shadow-lg border-t-8 border-orange-400"
            >
              <h2 className="text-3xl font-black mb-8 flex items-center gap-4 text-slate-900 dark:text-white uppercase tracking-tight">
                <div className="w-12 h-12 bg-blue-500 rounded-2xl flex items-center justify-center text-white shadow-md border-b-4 border-blue-700 text-2xl">
                  📖
                </div>
                Fiche Méthode
              </h2>
              <div className="text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
{methodContent()}
              </div>
              <button 
                onClick={() => setShowMethod(false)}
                className="w-full mt-10 py-5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-3xl font-black text-xl uppercase tracking-widest transition shadow-xl border-b-8 border-emerald-700 flex justify-center items-center gap-3 active:border-b-0 active:translate-y-2"
              >
                J'ai compris, on y va ! <ArrowRight size={24} />
              </button>
            </motion.div>
          ) : question && (
            <motion.div 
              key="quiz"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-panel p-8 sm:p-12 rounded-3xl w-full relative shadow-md"
            >
              <div className="flex justify-between items-center mb-10 text-xs font-black uppercase tracking-widest text-slate-400">
                <span className="bg-orange-100 text-orange-600 px-4 py-2 rounded-full border border-orange-200">Score: <span className="text-lg">{score}</span>/{asked}</span>
                <button 
                  onClick={() => setShowHint(true)}
                  className="flex items-center gap-2 hover:text-orange-500 transition disabled:opacity-50"
                  disabled={selectedAnswer !== null}
                >
                  <HelpCircle size={18} /> Besoin d'aide ?
                </button>
              </div>

              <div className="text-center mb-12">
                <div className="text-6xl sm:text-8xl font-black tracking-tighter mb-6 text-slate-900 dark:text-white font-mono">
                  {question.text}
                </div>
                {showHint && !selectedAnswer && (
                  id === 'fractions' && question.metadata ? (
                    <div className="flex flex-col gap-3 mt-4 mx-auto max-w-lg">
                      {(() => {
                        const { num, den } = question.metadata;
                        const hints = [];
                        
                        // Rule detection
                        if (num % 2 === 0 && den % 2 === 0) {
                          hints.push(`Concentre-toi sur les nombres : ${num} et ${den}. Sont-ils pairs ?`);
                          hints.push(`Comme les deux sont pairs, tu peux diviser le haut et le bas par 2 !`);
                        } else if ((num % 10 === 0 || num % 10 === 5) && (den % 10 === 0 || den % 10 === 5)) {
                          hints.push(`Regarde par quoi se terminent ${num} et ${den}. Remarques-tu un 0 ou un 5 ?`);
                          hints.push(`S'ils finissent par 0 ou 5, tu peux facilement les diviser par 5.`);
                        } else {
                          const sumOfDigits = (n: number) => String(n).split('').reduce((a, b) => a + Number(b), 0);
                          if (sumOfDigits(num) % 3 === 0 && sumOfDigits(den) % 3 === 0) {
                            hints.push(`Fais la somme des chiffres de ${num} (=${sumOfDigits(num)}) et ${den} (=${sumOfDigits(den)}). Sont-ils dans la table de 3 ?`);
                            hints.push(`Puisque la somme est dans la table de 3, tu peux diviser par 3.`);
                          } else {
                            hints.push(`Ils ne sont pas pairs, et ne se divisent ni par 5 ni par 3. Connais-tu tes tables de multiplication ? Cherche les tables de 4, 7 ou autre.`);
                          }
                        }

                        return (
                          <>
                            {hints.slice(0, hintStep + 1).map((h, i) => (
                              <motion.div key={i} initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}} className="text-amber-500 dark:text-amber-400 text-sm font-bold bg-amber-50 dark:bg-amber-900/20 p-4 rounded-xl border border-amber-200 dark:border-amber-800 text-left shadow-sm">
                                💡 {h}
                              </motion.div>
                            ))}
                            {hintStep + 1 < hints.length && (
                               <button 
                                 onClick={() => setHintStep(prev => prev + 1)}
                                 className="text-xs font-bold uppercase tracking-widest text-amber-600 dark:text-amber-400 hover:text-amber-700 bg-amber-100 dark:bg-amber-900/40 px-4 py-2 rounded-lg self-center mt-2 border border-amber-200 dark:border-amber-700"
                               >
                                 Indice suivant...
                               </button>
                            )}
                          </>
                        );
                      })()}
                    </div>
                  ) : (
                    <motion.div initial={{opacity:0, height:0}} animate={{opacity:1, height:'auto'}} className="text-amber-500 dark:text-amber-400 text-sm font-bold bg-amber-50 p-4 rounded-xl border border-amber-200 inline-block">
                      💡 Prends ton temps, essaie de décomposer le calcul.
                    </motion.div>
                  )
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {options.map((opt) => {
                  let btnStyle = "bg-white dark:bg-slate-800 border-4 border-slate-100 dark:border-slate-700 hover:border-blue-400 dark:hover:border-blue-600 text-slate-800 dark:text-slate-200 shadow-sm active:translate-y-1 active:border-b-0 border-b-8";
                  let icon = null;
                  
                  if (selectedAnswer) {
                    if (opt === String(question.answer)) {
                      btnStyle = "bg-emerald-500 border-4 border-emerald-600 border-b-8 text-white shadow-xl";
                      icon = <CheckCircle2 className="text-emerald-100" size={28} />;
                    } else if (opt === selectedAnswer) {
                      btnStyle = "bg-rose-500 border-4 border-rose-600 border-b-8 text-white shadow-xl";
                      icon = <XCircle className="text-rose-100" size={28} />;
                    } else {
                      btnStyle = "bg-slate-50 dark:bg-slate-800/50 border-4 border-transparent text-slate-400 dark:text-slate-500 opacity-50";
                    }
                  }

                  return (
                    <button
                      key={opt}
                      onClick={() => handleAnswer(opt)}
                      disabled={selectedAnswer !== null}
                      className={`relative flex items-center justify-center p-6 rounded-3xl text-3xl font-black transition-all ${btnStyle}`}
                    >
                      {opt}
                      <div className="absolute right-6">
                        {icon}
                      </div>
                    </button>
                  );
                })}
              </div>

              {selectedAnswer && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-10 space-y-6"
                >
                  {isCorrect ? (
                    <div className="p-6 bg-emerald-50 dark:bg-emerald-900/40 border-2 border-emerald-200 text-emerald-800 dark:text-emerald-300 rounded-2xl font-black text-center text-lg uppercase tracking-widest shadow-sm">
                      Excellent ! C'est la bonne réponse.
                    </div>
                  ) : (
                    <div className="p-6 bg-orange-50 dark:bg-orange-900/20 border-2 border-orange-200 dark:border-orange-800 rounded-2xl relative overflow-hidden shadow-sm">
                      <div className="flex items-center gap-3 mb-4 font-black uppercase tracking-widest text-orange-600 dark:text-orange-400">
                        <div className="w-8 h-8 rounded-lg border-2 border-orange-300 flex items-center justify-center bg-orange-100">
                          <BrainCircuit size={18} />
                        </div>
                        Professeur IA
                      </div>
                      {loadingAi ? (
                         <div className="flex items-center gap-2 text-slate-500 font-bold animate-pulse text-sm">
                           Génération de l'explication...
                         </div>
                      ) : (
                         <p className="text-sm font-medium text-slate-700 dark:text-slate-300 leading-relaxed bg-white p-4 rounded-xl border border-orange-100 shadow-inner">
                           {aiExplanation}
                         </p>
                      )}
                    </div>
                  )}

                  <button 
                    onClick={initQuestion}
                    className="w-full py-5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-3xl font-black uppercase tracking-widest text-xl hover:bg-slate-800 dark:hover:bg-slate-100 transition shadow-xl border-b-8 border-slate-700 flex justify-center items-center gap-3 active:border-b-0 active:translate-y-2"
                  >
                    Question suivante <ArrowRight size={24} />
                  </button>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
