/* eslint-disable */
'use client';

import { useStore } from '@/lib/store';
import { MODULE_INFO } from '@/lib/data';
import Navigation from '@/components/Navigation';
import { generateQuestion, getOptions, type Question, type ModuleId, type Level } from '@/lib/mathEngine';
import { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ChevronLeft, Brain, Zap, Clock, Trophy, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Link from 'next/link';
import confetti from 'canvas-confetti';

const TOTAL_QUESTIONS = 10;
const TIME_LIMITS: Record<Level, number> = {
  débutant: 20,
  confirmé: 15,
  expert: 10
};

export default function TestMode() {
  const { currentProfileId, updateModuleProgress, addXP, profiles, awardBadge } = useStore();
  const { id } = useParams() as { id: ModuleId };
  const router = useRouter();
  
  const [level, setLevel] = useState<Level | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [questions, setQuestions] = useState<{q: Question, opts: string[]}[]>([]);
  const [score, setScore] = useState(0);
  
  const [timeLeft, setTimeLeft] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [isFinished, setIsFinished] = useState(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const startGame = (selectedLevel: Level) => {
    setLevel(selectedLevel);
    // Generate 10 questions
    const qs = Array.from({length: TOTAL_QUESTIONS}).map(() => {
      const q = generateQuestion(id, selectedLevel);
      return { q, opts: getOptions(q) };
    });
    setQuestions(qs);
    setCurrentIndex(0);
    setScore(0);
    setIsFinished(false);
    setSelectedAnswer(null);
    setIsCorrect(null);
    setTimeLeft(TIME_LIMITS[selectedLevel]);
    setIsRunning(true);
  };

  const handleAnswer = (ans: string) => {
    if (selectedAnswer) return;
    setSelectedAnswer(ans);
    const correct = ans === String(questions[currentIndex].q.answer);
    setIsCorrect(correct);
    if (correct) setScore(pr => pr + 1);

    setTimeout(() => {
      if (currentIndex + 1 < TOTAL_QUESTIONS) {
        setCurrentIndex(pr => pr + 1);
        setSelectedAnswer(null);
        setIsCorrect(null);
        if (level) setTimeLeft(TIME_LIMITS[level]);
      } else {
        finishGame(correct ? score + 1 : score);
      }
    }, 1200);
  };

  useEffect(() => {
    if (isRunning && timeLeft > 0 && !selectedAnswer) {
      timerRef.current = setTimeout(() => {
        setTimeLeft(pr => pr - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning && !selectedAnswer) {
      // Time is up, count as wrong
      handleAnswer('TIMEOUT');
    }
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, [isRunning, timeLeft, selectedAnswer]);


  function finishGame(finalScore: number) {
    setIsRunning(false);
    setIsFinished(true);
    const pass = finalScore >= 6;
    const finalPct = Math.round((finalScore / TOTAL_QUESTIONS) * 100);
    
    if (level) {
      updateModuleProgress(id, level, finalPct);
    }

    if (pass) {
      addXP(100);
      confetti({ particleCount: 150, spread: 80, zIndex: 100 });
      if (id === 'fractions') awardBadge('pizza');
      if (id === 'conversions') awardBadge('mater');
      if (finalScore === 10) awardBadge('perfect10');
    }
  }

  if (!currentProfileId) {
    if (typeof window !== 'undefined') router.push('/');
    return null;
  }

  const profile = profiles.find(p => p.id === currentProfileId);
  const modProgress = profile?.modules[id];

  return (
    <div className="flex flex-col min-h-screen">
      <Navigation />
      
      <main className="flex-1 max-w-2xl w-full mx-auto p-4 sm:p-6 flex flex-col justify-center">
        {!isRunning && !isFinished && (
           <Link href={`/module/${id}`} className="absolute top-24 left-4 md:left-8 inline-flex items-center gap-2 text-xs font-black uppercase tracking-widest text-slate-400 hover:text-orange-500 transition z-10">
             <ChevronLeft size={16} /> Quitter le test
           </Link>
        )}

        <AnimatePresence mode="wait">
          {!level && !isRunning && !isFinished ? (
            <motion.div 
              key="start"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, y: -20 }}
              className="glass-panel p-8 sm:p-12 rounded-3xl text-center shadow-lg border-t-8 border-amber-400"
            >
              <div className="w-20 h-20 bg-amber-500 rounded-3xl flex items-center justify-center text-white mx-auto mb-6 shadow-md border-b-4 border-amber-700">
                <Zap size={40} className="fill-current" />
              </div>
              <h2 className="text-3xl font-black mb-4 uppercase tracking-tight text-slate-900 dark:text-white">Test Chronométré</h2>
              <p className="text-slate-500 dark:text-slate-400 mb-10 max-w-md mx-auto font-medium">
                10 questions. Pas d'assistance. Choisis ta difficulté. Obtiens 6/10 minimum pour valider le niveau !
              </p>

              <div className="flex flex-col gap-4 max-w-sm mx-auto">
                {(['débutant', 'confirmé', 'expert'] as Level[]).map((lvl) => {
                  const isCompleted = modProgress?.completedLevels[lvl];
                  return (
                    <button
                      key={lvl}
                      onClick={() => startGame(lvl)}
                      className="relative p-5 rounded-2xl border-2 border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:border-amber-400 dark:hover:border-amber-600 hover:shadow-md transition text-left flex items-center justify-between group active:scale-95"
                    >
                      <div>
                        <div className="font-black text-xl capitalize text-slate-800 dark:text-slate-100">{lvl}</div>
                        <div className="text-xs font-bold uppercase tracking-widest text-slate-400 mt-1">{TIME_LIMITS[lvl]}s / question</div>
                      </div>
                      <div className="flex items-center gap-4">
                        {isCompleted && <span className="text-[10px] font-black uppercase tracking-widest text-emerald-500 bg-emerald-50 dark:bg-emerald-900/40 px-3 py-1.5 rounded-full border border-emerald-200 dark:border-emerald-800/50">Validé</span>}
                        <ChevronLeft className="rotate-180 text-slate-300 group-hover:text-amber-500 transition" />
                      </div>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          ) : isRunning ? (
            <motion.div 
              key="quiz"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="glass-panel p-8 sm:p-12 rounded-3xl w-full relative shadow-md"
            >
              <div className="flex justify-between items-center mb-10 border-b-4 border-slate-100 dark:border-slate-800 pb-6">
                <div className="flex items-center gap-4">
                  <div className={`w-16 h-16 rounded-2xl border-4 flex items-center justify-center font-black text-2xl shadow-sm
                    ${timeLeft <= 5 ? 'border-rose-500 text-rose-500 bg-rose-50 dark:bg-rose-900/20 animate-pulse' : 'border-amber-500 text-amber-500 bg-amber-50 dark:bg-amber-900/20'}`}>
                    {timeLeft}
                  </div>
                  <Clock size={24} className="text-slate-300" />
                </div>
                <div className="text-xs font-black uppercase tracking-widest text-slate-400 bg-slate-100 dark:bg-slate-800 px-4 py-2 rounded-full">
                  QUESTION <span className="text-slate-800 dark:text-slate-200">{currentIndex + 1}</span> <span className="opacity-50">/ {TOTAL_QUESTIONS}</span>
                </div>
              </div>

              <div className="text-center mb-12">
                <div className="text-6xl sm:text-8xl font-black tracking-tighter text-slate-900 dark:text-white font-mono py-8">
                  {questions[currentIndex].q.text}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {questions[currentIndex].opts.map((opt) => {
                  let btnStyle = "bg-white dark:bg-slate-800 border-4 border-slate-100 dark:border-slate-700 hover:border-amber-400 dark:hover:border-amber-600 text-slate-800 dark:text-slate-200 shadow-sm border-b-8 active:border-b-0 active:translate-y-2";
                  
                  if (selectedAnswer) {
                    if (opt === String(questions[currentIndex].q.answer)) {
                      btnStyle = "bg-emerald-500 border-4 border-emerald-600 border-b-8 text-white shadow-xl";
                    } else if (opt === selectedAnswer) {
                      btnStyle = "bg-rose-500 border-4 border-rose-600 border-b-8 text-white shadow-xl";
                    } else {
                      btnStyle = "bg-slate-50 dark:bg-slate-800/50 border-4 border-transparent text-slate-400 dark:text-slate-500 opacity-50";
                    }
                  }

                  return (
                    <button
                      key={opt}
                      onClick={() => handleAnswer(opt)}
                      disabled={selectedAnswer !== null}
                      className={`p-6 rounded-3xl text-3xl font-black transition-all ${btnStyle}`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          ) : isFinished ? (
            <motion.div 
              key="result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="glass-panel p-8 sm:p-12 rounded-3xl text-center shadow-lg"
            >
              {score >= 6 ? (
                <>
                  <div className="inline-flex items-center justify-center w-24 h-24 bg-emerald-500 text-white rounded-3xl mb-8 shadow-lg border-b-4 border-emerald-700">
                    <Trophy size={48} />
                  </div>
                  <h2 className="text-4xl font-black mb-4 text-emerald-600 dark:text-emerald-400 uppercase tracking-tight">Niveau Validé !</h2>
                  <p className="text-lg font-medium text-slate-500 dark:text-slate-400 mb-10">
                    Bravo, tu as obtenu <span className="font-black text-2xl text-slate-800 dark:text-white px-2 bg-slate-100 dark:bg-slate-800 rounded-lg">{score}/{TOTAL_QUESTIONS}</span>. Ton score monte !
                  </p>
                </>
              ) : (
                <>
                  <div className="inline-flex items-center justify-center w-24 h-24 bg-rose-500 text-white rounded-3xl mb-8 shadow-lg border-b-4 border-rose-700">
                    <X size={48} />
                  </div>
                  <h2 className="text-4xl font-black mb-4 text-rose-600 dark:text-rose-400 uppercase tracking-tight">Presque !</h2>
                  <p className="text-lg font-medium text-slate-500 dark:text-slate-400 mb-10">
                    Tu as obtenu <span className="font-black text-2xl text-slate-800 dark:text-white px-2 bg-slate-100 dark:bg-slate-800 rounded-lg">{score}/{TOTAL_QUESTIONS}</span>. Il te faut au moins 6/10 pour valider. Retourne t'entraîner !
                  </p>
                </>
              )}
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  onClick={() => router.push(`/module/${id}`)}
                  className="px-8 py-4 bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 rounded-2xl font-black uppercase tracking-widest text-slate-600 dark:text-slate-300 hover:border-slate-400 transition"
                >
                  Retour
                </button>
                <button
                  onClick={() => setLevel(null)}
                  className="px-8 py-4 bg-amber-500 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-amber-600 transition shadow-lg border-b-4 border-amber-700 active:border-b-0 active:translate-y-1"
                >
                  Recommencer 
                </button>
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>
      </main>
    </div>
  );
}
