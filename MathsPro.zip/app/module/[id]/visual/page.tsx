/* eslint-disable */
'use client';

import { useStore } from '@/lib/store';
import Navigation from '@/components/Navigation';
import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { ChevronLeft, ArrowRight, RefreshCcw, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Link from 'next/link';
import confetti from 'canvas-confetti';

const EXERCISES = [
  { startNum: 4, startDen: 8, targetSteps: [[2, 4], [1, 2]] },
  { startNum: 6, startDen: 9, targetSteps: [[2, 3]] },
  { startNum: 10, startDen: 15, targetSteps: [[2, 3]] },
  { startNum: 12, startDen: 16, targetSteps: [[6, 8], [3, 4]] },
  { startNum: 18, startDen: 24, targetSteps: [[9, 12], [3, 4]] },
];

export default function VisualFractionsMode() {
  const { currentProfileId } = useStore();
  const { id } = useParams() as { id: string };
  const router = useRouter();

  if (id !== 'fractions') {
    if (typeof window !== 'undefined') router.push('/dashboard');
    return null;
  }

  const [currentEx, setCurrentEx] = useState(0);
  const [num, setNum] = useState(0);
  const [den, setDen] = useState(0);
  const [history, setHistory] = useState<{n: number, d: number}[]>([]);
  const [completed, setCompleted] = useState(false);

  useEffect(() => {
    loadExercise(0);
  }, []);

  const loadExercise = (idx: number) => {
    if (idx >= EXERCISES.length) {
      setCompleted(true);
      return;
    }
    const ex = EXERCISES[idx];
    setNum(ex.startNum);
    setDen(ex.startDen);
    setHistory([{ n: ex.startNum, d: ex.startDen }]);
    setCurrentEx(idx);
  };

  const handleDivide = (divisor: number) => {
    if (num % divisor === 0 && den % divisor === 0) {
      const newNum = num / divisor;
      const newDen = den / divisor;
      setNum(newNum);
      setDen(newDen);
      setHistory(prev => [...prev, { n: newNum, d: newDen }]);

      // Check if finished target steps
      const ex = EXERCISES[currentEx];
      const finalTarget = ex.targetSteps[ex.targetSteps.length - 1];
      if (newNum === finalTarget[0] && newDen === finalTarget[1]) {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.8 } });
        setTimeout(() => {
          loadExercise(currentEx + 1);
        }, 2000);
      }
    } else {
      // Error feedback (e.g. wiggle animation or toast)
      alert(`Impossible de diviser le haut ET le bas par ${divisor} de façon exacte !`);
    }
  };

  if (!currentProfileId) {
    if (typeof window !== 'undefined') router.push('/');
    return null;
  }

  // Determine grid template columns based on denominator to make it look like a bar
  const getGridCols = (d: number) => {
    if (d % 3 === 0 && d > 3) return d / 3;
    if (d % 4 === 0 && d > 4) return d / 4;
    if (d % 5 === 0 && d > 5) return d / 5;
    return d;
  };

  const cols = getGridCols(den);

  return (
    <div className="flex flex-col min-h-screen">
      <Navigation />
      
      <main className="flex-1 max-w-4xl w-full mx-auto p-4 sm:p-6 flex flex-col items-center">
        <div className="w-full relative flex justify-center mb-8">
          <Link href={`/module/${id}`} className="absolute left-0 top-1/2 -translate-y-1/2 inline-flex items-center gap-2 text-xs font-black uppercase tracking-widest text-slate-400 hover:text-emerald-500 transition">
            <ChevronLeft size={16} /> Quitter
          </Link>
          <div className="text-sm font-black uppercase tracking-widest text-emerald-500 bg-emerald-50 px-4 py-2 rounded-full border border-emerald-200">
            Exercice {Math.min(currentEx + 1, EXERCISES.length)} / {EXERCISES.length}
          </div>
        </div>

        {completed ? (
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="glass-panel p-12 rounded-3xl text-center shadow-lg w-full max-w-2xl mt-12 border-t-8 border-emerald-500">
            <div className="text-6xl mb-6">🏆</div>
            <h2 className="text-4xl font-black mb-4 uppercase tracking-tight text-emerald-600">Atelier Terminé !</h2>
            <p className="text-slate-600 mb-8 font-medium">Tu as compris visuellement comment simplifier des fractions en regroupant des parts.</p>
            <button onClick={() => router.push(`/module/${id}`)} className="px-8 py-4 bg-emerald-500 text-white font-black uppercase tracking-widest rounded-2xl shadow-lg border-b-4 border-emerald-700 hover:bg-emerald-600 transition active:border-b-0 active:translate-y-1">
              Retour au module
            </button>
          </motion.div>
        ) : (
          <div className="w-full max-w-3xl glass-panel p-8 sm:p-12 rounded-3xl shadow-lg relative overflow-hidden">
             <div className="text-center mb-10">
                <h2 className="text-3xl font-black uppercase tracking-tight text-slate-900 dark:text-white mb-2">Simplification Visuelle</h2>
                <p className="text-slate-500 font-medium">Sélectionne un diviseur commun pour regrouper les parts (simplifier).</p>
             </div>

             <div className="flex flex-col md:flex-row gap-12 items-center justify-center">
                {/* Visual Representation */}
                <div className="flex flex-col items-center gap-4">
                  <div className="flex items-center gap-6">
                    {/* The Fraction Text block */}
                    <div className="flex flex-col items-center justify-center text-4xl font-black font-mono text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 p-6 rounded-2xl border-4 border-slate-200 dark:border-slate-700 shadow-inner">
                       <span className="mb-2">{num}</span>
                       <div className="h-2 w-16 bg-slate-400 dark:bg-slate-600 rounded-full"></div>
                       <span className="mt-2">{den}</span>
                    </div>

                    <ArrowRight size={32} className="text-slate-300" />

                    {/* The Visual Grid block */}
                    <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border-4 border-slate-100 dark:border-slate-800 shadow-sm">
                       <div 
                         className="grid gap-1"
                         style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}
                       >
                         {Array.from({ length: den }).map((_, i) => (
                           <motion.div 
                             key={`${den}-${i}`} // Key changes when den changes for animation
                             initial={{ scale: 0 }}
                             animate={{ scale: 1 }}
                             transition={{ delay: i * 0.02 }}
                             className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg border-2 ${
                               i < num 
                                 ? 'bg-emerald-400 border-emerald-500 shadow-sm' 
                                 : 'bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                             }`}
                           />
                         ))}
                       </div>
                    </div>
                  </div>
                  
                  {/* History of steps */}
                  {history.length > 1 && (
                    <div className="text-sm font-bold text-slate-400 mt-4 flex items-center gap-2 flex-wrap justify-center">
                      Historique : 
                      {history.map((step, i) => (
                         <span key={i} className="flex items-center gap-2">
                           {i > 0 && <span>→</span>}
                           <span className="bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-md">{step.n}/{step.d}</span>
                         </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Controls */}
                <div className="flex flex-col gap-4 min-w-[200px]">
                   <h3 className="font-black text-sm uppercase tracking-widest text-slate-400 mb-2 text-center md:text-left">Diviser par :</h3>
                   {[2, 3, 4, 5].map(divisor => {
                      return (
                        <button
                          key={divisor}
                          onClick={() => handleDivide(divisor)}
                          className="py-4 px-6 bg-white dark:bg-slate-800 rounded-2xl font-black text-xl text-slate-700 dark:text-slate-200 border-4 border-slate-100 dark:border-slate-700 hover:border-emerald-400 dark:hover:border-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition shadow-sm active:translate-y-1 active:border-b-0 border-b-8 flex justify-between items-center group"
                        >
                          <span>÷ {divisor}</span>
                          <span className="opacity-0 group-hover:opacity-100 transition text-emerald-500">Groupes de {divisor}</span>
                        </button>
                      );
                   })}
                   
                   <button 
                     onClick={() => loadExercise(currentEx)}
                     className="mt-6 py-3 px-6 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 font-bold flex items-center justify-center gap-2 border-2 border-transparent hover:border-slate-200 dark:hover:border-slate-700 rounded-xl transition"
                   >
                     <RefreshCcw size={16} /> Réinitialiser
                   </button>
                </div>
             </div>
          </div>
        )}
      </main>
    </div>
  );
}
