'use client';

import { useStore } from '@/lib/store';
import { MODULE_INFO } from '@/lib/data';
import Navigation from '@/components/Navigation';
import { useRouter } from 'next/navigation';
import { motion } from 'motion/react';
import { Star, Lock, Medal, Flame, ChevronRight } from 'lucide-react';
import type { ModuleId } from '@/lib/mathEngine';

export default function Dashboard() {
  const { profiles, currentProfileId, toggleFocusModule } = useStore();
  const router = useRouter();

  const profile = profiles.find(p => p.id === currentProfileId);

  if (!profile) {
    if (typeof window !== 'undefined') router.push('/');
    return null;
  }

  const moduleIds = Object.keys(MODULE_INFO) as ModuleId[];

  return (
    <div className="flex flex-col min-h-screen">
      <Navigation />
      
      <main className="flex-1 max-w-5xl w-full mx-auto p-4 sm:p-6 py-8">
        {/* Profile Header */}
        <section className="glass-panel p-6 sm:p-8 mb-8 flex flex-col md:flex-row items-center gap-8 border-b-4 border-orange-200 dark:border-orange-900">
          <div className="relative">
            <div className="w-24 h-24 sm:w-32 sm:h-32 bg-orange-500 rounded-2xl flex items-center justify-center text-5xl sm:text-6xl shadow-lg border-4 border-white dark:border-slate-800">
              {profile.avatar}
            </div>
            <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-emerald-500 text-white font-black px-4 py-1 rounded-full text-sm border-2 border-white dark:border-slate-800 shadow-sm uppercase tracking-wider">
              Niv {profile.level}
            </div>
          </div>
          
          <div className="flex-1 text-center md:text-left space-y-4 mt-4 md:mt-0">
            <h1 className="text-4xl font-black tracking-tight text-slate-900 dark:text-white">Bonjour {profile.name} !</h1>
            
            <div className="flex flex-wrap justify-center md:justify-start gap-4">
              <div className="flex items-center gap-3 bg-white dark:bg-slate-800 px-5 py-3 rounded-2xl shadow-sm border-2 border-slate-100 dark:border-slate-700">
                <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/40 rounded-lg flex items-center justify-center text-orange-600 dark:text-orange-400">
                  <Medal size={24} />
                </div>
                <div>
                  <div className="text-xs font-black uppercase text-slate-400 tracking-widest">Expérience</div>
                  <div className="font-black text-xl">{profile.xp} <span className="text-orange-500">XP</span></div>
                </div>
              </div>
              <div className="flex items-center gap-3 bg-white dark:bg-slate-800 px-5 py-3 rounded-2xl shadow-sm border-2 border-slate-100 dark:border-slate-700">
                <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/40 rounded-lg flex items-center justify-center">
                  <Flame className={profile.streak > 0 ? "text-emerald-500" : "text-slate-400"} size={24} />
                </div>
                <div>
                  <div className="text-xs font-black uppercase text-slate-400 tracking-widest">Série (Jours)</div>
                  <div className="font-black text-xl">{profile.streak}</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Modules Grid */}
        <h2 className="text-xs font-black uppercase text-slate-400 mb-6 tracking-widest">
          Mes Entraînements ({moduleIds.length})
        </h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {moduleIds.map((id, index) => {
            const info = MODULE_INFO[id];
            const modProgress = profile.modules[id];
            const isUnlocked = modProgress?.unlocked ?? true;
            
            return (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                key={id}
                className={`relative glass-panel p-6 transition-all group ${isUnlocked ? 'hover:shadow-md hover:border-orange-400 dark:hover:border-orange-600 cursor-pointer' : 'opacity-75 grayscale'}`}
                onClick={() => { if (isUnlocked) router.push(`/module/${id}`) }}
              >
                {/* Focus Star */}
                {isUnlocked && (
                  <button 
                    onClick={(e) => { e.stopPropagation(); toggleFocusModule(id); }}
                    className="absolute top-4 right-4 p-2 w-10 h-10 rounded-lg flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                  >
                    <Star 
                      size={20} 
                      className={modProgress?.isFocus ? "fill-orange-500 text-orange-500" : "text-slate-300 dark:text-slate-600"} 
                    />
                  </button>
                )}
                
                <div className="text-5xl mb-4 p-4 bg-orange-50 dark:bg-slate-800/50 rounded-2xl inline-block border-2 border-orange-100 dark:border-slate-700">{info.icon}</div>
                <h3 className="font-black text-2xl mb-2 text-slate-900 dark:text-white">{info.title}</h3>
                <p className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-6 leading-relaxed">{info.description}</p>
                
                <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800 pt-5 mt-auto">
                  {!isUnlocked ? (
                     <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-slate-400">
                      <Lock size={16} /> Verrouillé
                    </div>
                  ) : (
                    <>
                      <div className="text-xs font-black uppercase tracking-widest text-emerald-500">
                        {modProgress?.highScore > 0 ? `Record : ${modProgress.highScore}%` : 'À découvrir'}
                      </div>
                      <div className="text-emerald-500 transform group-hover:translate-x-2 transition-transform bg-emerald-50 dark:bg-emerald-900/30 p-2 rounded-lg">
                        <ChevronRight size={20} />
                      </div>
                    </>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </main>
    </div>
  );
}
