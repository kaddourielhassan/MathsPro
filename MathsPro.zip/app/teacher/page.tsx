'use client';

import { useStore, type UserProfile } from '@/lib/store';
import Navigation from '@/components/Navigation';
import { jsPDF } from 'jspdf';
import { Download, CheckCircle, ShieldCheck, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { MODULE_INFO } from '@/lib/data';
import type { ModuleId } from '@/lib/mathEngine';

export default function TeacherDashboard() {
  const { profiles, role } = useStore();

  if (role !== 'teacher') {
    return (
      <div className="flex flex-col min-h-screen">
        <Navigation />
        <main className="flex-1 flex items-center justify-center p-4">
          Accès refusé.
        </main>
      </div>
    );
  }

  const exportPDF = (profile: UserProfile) => {
    const doc = new jsPDF();
    
    // Header
    doc.setFontSize(22);
    doc.setTextColor(79, 70, 229); // Indigo 600
    doc.text('MathsPro - Bilan de Compétences', 105, 20, { align: 'center' });
    
    doc.setFontSize(14);
    doc.setTextColor(15, 23, 42);
    doc.text(`Élève : ${profile.name}`, 20, 40);
    doc.text(`Niveau global : ${profile.level} (${profile.xp} XP)`, 20, 50);
    doc.text(`Série de jours : ${profile.streak}`, 20, 60);
    doc.text(`Date de création : ${format(profile.createdAt, 'dd MMMM yyyy', { locale: fr })}`, 20, 70);

    // Badges
    if (profile.badges.length > 0) {
      doc.setFontSize(12);
      doc.text(`Badges obtenus : ${profile.badges.length}`, 20, 85);
    }

    // Table Header
    doc.setFontSize(12);
    doc.setFillColor(241, 245, 249);
    doc.rect(20, 95, 170, 10, 'F');
    doc.setFont('helvetica', 'bold');
    doc.text('Module', 25, 102);
    doc.text('Progression', 130, 102);
    doc.text('Score', 160, 102);
    
    // Table content
    doc.setFont('helvetica', 'normal');
    let y = 115;
    const moduleIds = Object.keys(MODULE_INFO) as ModuleId[];
    
    moduleIds.forEach((id) => {
      const info = MODULE_INFO[id];
      const mod = profile.modules[id];
      doc.text(info.title, 25, y);
      
      const levelsStr = Object.entries(mod.completedLevels)
        .filter(([_, v]) => v)
        .map(([k]) => k.substring(0, 3).toUpperCase())
        .join(', ') || '-';
        
      doc.text(levelsStr, 130, y);
      doc.text(mod.highScore > 0 ? `${mod.highScore}%` : 'N/A', 160, y);
      
      y += 10;
    });

    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text('Généré automatiquement par MathsPro', 105, 280, { align: 'center' });
    
    doc.save(`Resultats_${profile.name}.pdf`);
  };

  const exportAttestation = (profile: UserProfile) => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text('Attestation de Travail en Autonomie', 105, 30, { align: 'center' });
    doc.setFontSize(12);
    doc.text(`Je soussigné(e), Professeur ou responsable de Vie Scolaire, atteste que l'élève :`, 20, 60);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text(profile.name, 105, 80, { align: 'center' });
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    
    const validatedMods = Object.values(profile.modules).filter(m => Object.values(m.completedLevels).some(v => v)).length;
    
    doc.text(`A travaillé sérieusement sur la plateforme MathsPro.`, 20, 100);
    doc.text(`- Nombre de modules validés : ${validatedMods}/10`, 25, 110);
    doc.text(`- Expérience accumulée : ${profile.xp} XP`, 25, 120);
    
    doc.text(`Fait pour valoir ce que de droit.`, 20, 150);
    doc.text(`Date : ${format(Date.now(), 'dd/MM/yyyy')}`, 20, 160);
    doc.text(`Signature :`, 130, 160);
    
    doc.save(`Attestation_${profile.name}.pdf`);
  };

  const exportCSV = () => {
    const header = "Nom,XP,Niveau,Serie,Addition_Score,Soustraction_Score\n";
    const rows = profiles.map(p => {
       return `${p.name},${p.xp},${p.level},${p.streak},${p.modules['addition']?.highScore || 0},${p.modules['subtraction']?.highScore || 0}`;
    });
    const csvContent = "data:text/csv;charset=utf-8," + header + rows.join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "MathsPro_Export.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navigation />
      
      <main className="flex-1 max-w-5xl w-full mx-auto p-4 sm:p-6 py-8">
        <div className="bg-emerald-500 rounded-3xl p-8 sm:p-10 mb-8 flex flex-col md:flex-row justify-between items-center gap-6 shadow-lg border-b-8 border-emerald-700 text-white relative overflow-hidden">
           <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMiIgZmlsbD0icmdiYSgyNTUsIDI1NSwgMjU1LCAwLjA1KSIvPjwvc3ZnPg==')] opacity-50"></div>
          <div className="relative z-10 w-full md:w-auto">
            <h1 className="text-3xl sm:text-4xl font-black flex items-center gap-4 mb-2 uppercase tracking-tight">
              <div className="bg-white text-emerald-500 p-2 rounded-2xl shadow-sm rotate-3">
                 <ShieldCheck size={36} className="fill-current text-white" />
              </div>
              Espace Enseignant
            </h1>
            <p className="font-medium text-emerald-100 max-w-lg">Vue consolidée des progrès de tous les élèves enregistrés sur cet appareil.</p>
          </div>
          <button 
            onClick={exportCSV}
            className="w-full md:w-auto flex items-center justify-center gap-3 px-6 py-4 bg-white text-emerald-600 font-black uppercase tracking-widest rounded-2xl hover:bg-emerald-50 transition shadow-md border-b-4 border-emerald-200 active:border-b-0 active:translate-y-1 relative z-10"
          >
            <Download size={20} /> Export CSV Global
          </button>
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-3xl shadow-sm border-2 border-slate-100 dark:border-slate-700 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-900/50 border-b-2 border-slate-100 dark:border-slate-700 text-xs font-black uppercase tracking-widest text-slate-400">
                <tr>
                  <th className="p-5">Élève</th>
                  <th className="p-5">Niveau</th>
                  <th className="p-5">XP</th>
                  <th className="p-5">Série</th>
                  <th className="p-5">Certificats & Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y-2 divide-slate-50 dark:divide-slate-700/50">
                {profiles.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/80 transition">
                    <td className="p-5 flex items-center gap-4">
                      <div className="text-3xl bg-slate-100 dark:bg-slate-700 w-12 h-12 flex items-center justify-center rounded-2xl">{p.avatar}</div>
                      <span className="font-bold text-slate-900 dark:text-slate-100">{p.name}</span>
                    </td>
                    <td className="p-5 font-mono font-black text-blue-500 dark:text-blue-400 text-lg uppercase">{p.level}</td>
                    <td className="p-5 font-bold text-slate-600 dark:text-slate-300">{p.xp}</td>
                    <td className="p-5 font-bold text-orange-500">{p.streak} j</td>
                    <td className="p-5 flex gap-3">
                      <button 
                        onClick={() => exportPDF(p)}
                        className="p-3 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl hover:bg-blue-100 transition shadow-sm border border-blue-100 dark:border-blue-800"
                        title="Bilan Complet"
                      >
                        <FileText size={20} />
                      </button>
                      <button 
                        onClick={() => exportAttestation(p)}
                        className="p-3 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl hover:bg-emerald-100 transition shadow-sm border border-emerald-100 dark:border-emerald-800"
                        title="Attestation Vie Scolaire"
                      >
                        <CheckCircle size={20} />
                      </button>
                    </td>
                  </tr>
                ))}
                {profiles.length === 0 && (
                  <tr>
                    <td colSpan={5} className="p-12 text-center font-medium text-slate-500">
                      Aucun profil élève enregistré pour le moment.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

      </main>
    </div>
  );
}
