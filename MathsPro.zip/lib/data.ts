import type { ModuleId } from '@/lib/mathEngine';

export const MODULE_INFO: Record<ModuleId, { title: string; description: string; icon: string }> = {
  addition: { title: "Additions", description: "L'art d'ajouter sans erreur.", icon: "➕" },
  subtraction: { title: "Soustractions", description: "Gérer l'écart et le complément.", icon: "➖" },
  mul1_10: { title: "Tables x1 à x10", description: "Maitrise des tables de multiplication.", icon: "✖️" },
  mul2_3digits: { title: "Multiplications Complexes", description: "Nombres à 2 et 3 chiffres.", icon: "🔢" },
  division: { title: "Divisions", description: "La multiplication à l'envers.", icon: "➗" },
  fractions: { title: "Fractions & Simplification", description: "Par petites divisions.", icon: "🍕" },
  decimals: { title: "Pourcentages", description: "Proportions et parts.", icon: "💯" },
  rounding: { title: "Arrondis", description: "Estimer correctement.", icon: "🔄" },
  conversions: { title: "Conversions de Longueurs", description: "Le système métrique.", icon: "📏" },
  mul10: { title: "×10, 100, 1000", description: "Décaler la virgule (droite).", icon: "⏩" },
  div10: { title: "÷10, 100, 1000", description: "Décaler la virgule (gauche).", icon: "⏪" },
};
