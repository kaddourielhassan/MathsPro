import { GoogleGenAI } from '@google/genai';

const getAi = () => {
  const apiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("GEMINI_API_KEY is missing. AI explanations will be disabled.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const getExplanation = async (question: string, wrongAnswer: string, correctAnswer: string): Promise<string> => {
  const ai = getAi();
  if (!ai) return "L'explication IA n'est pas disponible car la clé API est manquante.";
  
  try {
    const prompt = `Un élève de lycée professionnel a fait une erreur en calcul mental.
Le calcul était : ${question}
La réponse correcte est : ${correctAnswer}
L'élève a répondu : ${wrongAnswer}

Fournis une explication très brève, bienveillante et pédagogique pour l'aider à comprendre son erreur, sans le juger. 
Sois direct et simple. Utilise un ton encourageant. Le contexte est un lycée pro. Maximum 2 ou 3 phrases.`;

    // Use a faster, lighter model for these quick explanations
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    
    return response.text || "Erreur de génération d'explication.";
  } catch (err) {
    console.error("Erreur Gemini:", err);
    return "Erreur lors de la récupération de l'explication (Vérifiez la clé API).";
  }
};
