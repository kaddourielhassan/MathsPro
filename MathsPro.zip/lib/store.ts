import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type UserRole = 'student' | 'teacher';
export type Level = 'débutant' | 'confirmé' | 'expert';

export interface ModuleProgress {
  id: string;
  unlocked: boolean;
  score: number; // last score
  highScore: number;
  completedLevels: Record<Level, boolean>;
  isFocus: boolean; // starred
}

export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  xp: number;
  level: number;
  streak: number;
  badges: string[];
  modules: Record<string, ModuleProgress>;
  createdAt: number;
}

interface AppState {
  profiles: UserProfile[];
  currentProfileId: string | null;
  role: UserRole;
  settings: {
    darkMode: boolean;
    dyslexiaMode: boolean;
  };
  addProfile: (name: string, avatar: string) => void;
  setCurrentProfile: (id: string | null) => void;
  setRole: (role: UserRole) => void;
  toggleDarkMode: () => void;
  toggleDyslexiaMode: () => void;
  toggleFocusModule: (moduleId: string) => void;
  addXP: (amount: number) => void;
  updateModuleProgress: (moduleId: string, level: Level, score: number) => void;
  awardBadge: (badgeId: string) => void;
  incrementStreak: () => void;
  resetStreak: () => void;
  deleteProfile: (id: string) => void;
}

const INITIAL_MODULES = [
  'addition', 'subtraction', 'multiplication', 'division',
  'fractions', 'decimals', 'rounding', 'conversions',
  'mul10', 'div10'
];

const createInitialModules = () => {
  const mods: Record<string, ModuleProgress> = {};
  INITIAL_MODULES.forEach(id => {
    mods[id] = {
      id,
      unlocked: id === 'addition', // Only first unlocked initially? Let's unlock all for now for testing, or follow standard. The spec says "accès aux 10 modules", so we unlock all.
      score: 0,
      highScore: 0,
      completedLevels: { débutant: false, confirmé: false, expert: false },
      isFocus: false,
    };
  });
  return mods;
};

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      profiles: [],
      currentProfileId: null,
      role: 'student',
      settings: {
        darkMode: false,
        dyslexiaMode: false,
      },

      addProfile: (name, avatar) => set((state) => {
        const id = Math.random().toString(36).substring(2, 9);
        const newProfile: UserProfile = {
          id,
          name,
          avatar,
          xp: 0,
          level: 1,
          streak: 0,
          badges: [],
          modules: createInitialModules(),
          createdAt: Date.now(),
        };
        // By default, open access to all modules since spec says "accès aux 10 modules"
        Object.values(newProfile.modules).forEach(m => m.unlocked = true);
        return { profiles: [...state.profiles, newProfile], currentProfileId: id, role: 'student' };
      }),

      setCurrentProfile: (id) => set({ currentProfileId: id }),
      setRole: (role) => set({ role }),
      
      toggleDarkMode: () => set((state) => ({ settings: { ...state.settings, darkMode: !state.settings.darkMode } })),
      toggleDyslexiaMode: () => set((state) => ({ settings: { ...state.settings, dyslexiaMode: !state.settings.dyslexiaMode } })),
      
      toggleFocusModule: (moduleId) => set((state) => {
        if (!state.currentProfileId) return state;
        const profiles = state.profiles.map(p => {
          if (p.id === state.currentProfileId) {
            const mod = p.modules[moduleId] || {
              id: moduleId,
              unlocked: true,
              score: 0,
              highScore: 0,
              completedLevels: { débutant: false, confirmé: false, expert: false },
              isFocus: false,
            };
            return {
              ...p,
              modules: {
                ...p.modules,
                [moduleId]: {
                   ...mod,
                   isFocus: !mod.isFocus
                }
              }
            };
          }
          return p;
        });
        return { profiles };
      }),

      addXP: (amount) => set((state) => {
        if (!state.currentProfileId) return state;
        const profiles = state.profiles.map(p => {
          if (p.id === state.currentProfileId) {
            const newXp = p.xp + amount;
            const newLevel = Math.floor(newXp / 500) + 1;
            return { ...p, xp: newXp, level: newLevel };
          }
          return p;
        });
        return { profiles };
      }),

      updateModuleProgress: (moduleId, level, score) => set((state) => {
        if (!state.currentProfileId) return state;
        const profiles = state.profiles.map(p => {
          if (p.id === state.currentProfileId) {
            const mod = p.modules[moduleId] || {
              id: moduleId,
              unlocked: true,
              score: 0,
              highScore: 0,
              completedLevels: { débutant: false, confirmé: false, expert: false },
              isFocus: false,
            };
            return {
              ...p,
              modules: {
                ...p.modules,
                [moduleId]: {
                  ...mod,
                  score,
                  highScore: Math.max(mod.highScore, score),
                  completedLevels: {
                    ...mod.completedLevels,
                    [level]: mod.completedLevels[level] || score >= 60
                  }
                }
              }
            };
          }
          return p;
        });
        return { profiles };
      }),

      awardBadge: (badgeId) => set((state) => {
        if (!state.currentProfileId) return state;
        const profiles = state.profiles.map(p => {
          if (p.id === state.currentProfileId && !p.badges.includes(badgeId)) {
             return { ...p, badges: [...p.badges, badgeId] };
          }
          return p;
        });
        return { profiles };
      }),

      incrementStreak: () => set((state) => {
        if (!state.currentProfileId) return state;
        const profiles = state.profiles.map(p => {
          if (p.id === state.currentProfileId) {
             return { ...p, streak: p.streak + 1 };
          }
          return p;
        });
        return { profiles };
      }),

      resetStreak: () => set((state) => {
        if (!state.currentProfileId) return state;
        const profiles = state.profiles.map(p => {
          if (p.id === state.currentProfileId) {
             return { ...p, streak: 0 };
          }
          return p;
        });
        return { profiles };
      }),
      deleteProfile: (id) => set((state) => {
        const remaining = state.profiles.filter(p => p.id !== id);
        return { profiles: remaining, currentProfileId: state.currentProfileId === id ? null : state.currentProfileId };
      })
    }),
    {
      name: 'mathspro-storage',
    }
  )
);
