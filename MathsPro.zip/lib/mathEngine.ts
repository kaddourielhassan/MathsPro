export type ModuleId =
  | 'addition'
  | 'subtraction'
  | 'mul1_10'
  | 'mul2_3digits'
  | 'division'
  | 'fractions'
  | 'decimals'
  | 'rounding'
  | 'conversions'
  | 'mul10'
  | 'div10';

export type Level = 'débutant' | 'confirmé' | 'expert';

export interface Question {
  text: string;
  answer: string | number;
  distractors: (string | number)[];
  explanation?: string;
  metadata?: any;
}

const randomInt = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;
const shuffle = <T>(array: T[]) => array.sort(() => Math.random() - 0.5);

// Distractor generators
const genAddDistractors = (ans: number, a: number, b: number) => [
  ans + 10,
  ans - 10,
  ans + Math.abs(a - b) % 10 + 1,
].map(String);

const genSubDistractors = (ans: number, a: number, b: number) => [
  ans + 10,
  ans - 10,
  a + b,
].map(String);

const genMulDistractors = (ans: number, a: number, b: number) => [
  ans + a,
  ans - a,
  ans + b,
].map(String);

const genDivDistractors = (ans: number, b: number) => [
  ans * 10,
  ans + 1,
  Math.max(1, ans - 1),
].map(String);

const simplifyFraction = (num: number, den: number): [number, number] => {
  const gcd = (a: number, b: number): number => b === 0 ? a : gcd(b, a % b);
  const d = gcd(num, den);
  return [num / d, den / d];
};

export const generateQuestion = (moduleId: ModuleId, level: Level): Question => {
  switch (moduleId) {
    case 'addition': {
      let a, b;
      if (level === 'débutant') {
        a = randomInt(11, 99);
        b = randomInt(11, 99);
      } else if (level === 'confirmé') {
        a = randomInt(100, 999);
        b = randomInt(10, 99);
      } else {
        a = randomInt(1000, 9999);
        b = randomInt(100, 999);
      }
      const ans = a + b;
      return {
        text: `${a} + ${b}`,
        answer: String(ans),
        distractors: genAddDistractors(ans, a, b),
      };
    }
    case 'subtraction': {
      let a, b;
      if (level === 'débutant') {
        a = randomInt(20, 99);
        b = randomInt(10, a - 1);
      } else if (level === 'confirmé') {
        a = randomInt(100, 999);
        b = randomInt(10, 99);
      } else {
        a = randomInt(1000, 9999);
        b = randomInt(100, 999);
      }
      const ans = a - b;
      return {
        text: `${a} - ${b}`,
        answer: String(ans),
        distractors: genSubDistractors(ans, a, b),
      };
    }
    case 'mul1_10': {
      let a, b;
      if (level === 'débutant') {
        a = randomInt(1, 5);
        b = randomInt(1, 5);
      } else if (level === 'confirmé') {
        a = randomInt(2, 9);
        b = randomInt(2, 9);
      } else {
        a = randomInt(6, 10);
        b = randomInt(6, 10);
      }
      const ans = a * b;
      return {
        text: `${a} × ${b}`,
        answer: String(ans),
        distractors: genMulDistractors(ans, a, b),
      };
    }
    case 'mul2_3digits': {
      let a, b;
      if (level === 'débutant') {
        a = randomInt(10, 99);
        b = randomInt(2, 9);
      } else if (level === 'confirmé') {
        a = randomInt(10, 99);
        b = randomInt(10, 99);
      } else {
        a = randomInt(100, 999);
        b = randomInt(10, 99);
      }
      const ans = a * b;
      return {
        text: `${a} × ${b}`,
        answer: String(ans),
        distractors: genMulDistractors(ans, a, b),
      };
    }
    case 'division': {
      let ans, b;
      if (level === 'débutant') {
        ans = randomInt(2, 9);
        b = randomInt(2, 9);
      } else if (level === 'confirmé') {
        ans = randomInt(10, 50);
        b = randomInt(2, 9);
      } else {
        ans = randomInt(10, 99);
        b = randomInt(10, 20);
      }
      const a = ans * b;
      return {
        text: `${a} ÷ ${b}`,
        answer: String(ans),
        distractors: genDivDistractors(ans, b),
      };
    }
    case 'fractions': {
      // Successive divisions per spec
      let num, den;
      if (level === 'débutant') {
        // e.g. 12/8 -> 3/2
        const baseNum = randomInt(2, 9);
        const baseDen = randomInt(2, 9);
        const mult = randomInt(2, 5); // 1 division step
        num = baseNum * mult;
        den = baseDen * mult;
      } else if (level === 'confirmé') {
        const baseNum = randomInt(2, 9);
        const baseDen = randomInt(2, 9);
        const mult1 = randomInt(2, 5);
        const mult2 = randomInt(2, 5); // 2 steps
        num = baseNum * mult1 * mult2;
        den = baseDen * mult1 * mult2;
      } else {
        const baseNum = randomInt(2, 9);
        const baseDen = randomInt(2, 9);
        const mult = [2, 3, 5][randomInt(0, 2)] * [2, 3][randomInt(0, 1)] * [2, 5][randomInt(0, 1)]; // 3+ steps
        num = baseNum * mult;
        den = baseDen * mult;
      }
      
      const [simpNum, simpDen] = simplifyFraction(num, den);
      const answer = `${simpNum}/${simpDen}`;
      
      return {
        text: `${num} / ${den}`,
        answer,
        distractors: [
          `${num / 2}/${den / 2}`, // partial
          `${simpDen}/${simpNum}`, // inverted
          `${simpNum + 1}/${simpDen}`, // wrong
        ],
        metadata: { num, den, simpNum, simpDen }
      };
    }
    case 'decimals': {
      // pourcentages
      const bases = [10, 20, 25, 50];
      const pct = bases[randomInt(0, bases.length - 1)];
      const num = randomInt(2, 100) * (pct === 20 || pct === 25 ? 10 : 2); // ensure friendly numbers
      const ans = (num * pct) / 100;
      return {
        text: `${pct}% de ${num}`,
        answer: String(ans),
        distractors: [String(ans * 10), String(ans / 10), String(num - pct)]
      }
    }
    case 'rounding': {
      // Arrondis: 5 ou plus on monte
      const units = randomInt(1, 100);
      const decimal = randomInt(1, 9);
      const num = parseFloat(`${units}.${decimal}`);
      const ans = Math.round(num);
      return {
        text: `Arrondir à l'entier : ${num.toFixed(1)}`,
        answer: String(ans),
        distractors: [String(ans > num ? ans - 1 : ans + 1), String(num * 10), String(ans + 10)]
      }
    }
    case 'conversions': {
      // 1 m = 10 dm = 100 cm = 1000 mm
      const units = ['m', 'dm', 'cm', 'mm'];
      const fromIdx = randomInt(0, 2);
      const toIdx = randomInt(fromIdx + 1, 3);
      const val = randomInt(1, 50);
      const mult = Math.pow(10, toIdx - fromIdx);
      const ans = val * mult;
      return {
        text: `${val} ${units[fromIdx]} en ${units[toIdx]}`,
        answer: String(ans),
        distractors: [String(val / mult), String(ans * 10), String(ans / 10)]
      }
    }
    case 'mul10': {
      const pow = Math.pow(10, randomInt(1, 3));
      const val = level === 'débutant' ? randomInt(2, 99) : parseFloat((randomInt(1, 999) / 10).toFixed(1));
      const ans = val * pow;
      return {
        text: `${val} × ${pow}`,
        answer: String(ans),
        distractors: [String(val / pow), String(ans * 10), String(ans / 10)]
      }
    }
    case 'div10': {
      const pow = Math.pow(10, randomInt(1, 3));
      const val = level === 'débutant' ? randomInt(1, 9) * 1000 : randomInt(100, 9999);
      const ans = val / pow;
      return {
        text: `${val} ÷ ${pow}`,
        answer: String(ans),
        distractors: [String(val * pow), String(ans * 10), String(ans / 10)]
      }
    }
    default:
      return {
        text: '1 + 1',
        answer: '2',
        distractors: ['3', '4', '11']
      }
  }
};

export const getOptions = (question: Question): string[] => {
  // deduplicate and shuffle
  const items = new Set([String(question.answer), ...question.distractors.map(String)]);
  // if not enough distractors due to dedup, add some random
  let arr = Array.from(items);
  while(arr.length < 4) {
    const r = parseFloat(String(question.answer)) + randomInt(1, 5);
    if (!arr.includes(String(r))) arr.push(String(r));
  }
  return shuffle(arr).slice(0, 4);
};
