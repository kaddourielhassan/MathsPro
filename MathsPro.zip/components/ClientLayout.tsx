'use client';

import { useStore } from '@/lib/store';
import { useEffect, useState } from 'react';

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const { settings } = useStore();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setMounted(true), 10);
    return () => clearTimeout(timer);
  }, []);

  if (!mounted) {

    return <div className="min-h-screen bg-orange-50 dark:bg-slate-900" />;
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${settings.darkMode ? 'dark' : ''}`}>
      <div className={`min-h-screen bg-orange-50 dark:bg-slate-900 text-slate-800 dark:text-slate-50 ${settings.dyslexiaMode ? 'dyslexia-mode' : 'font-sans'}`}>
        {children}
      </div>
    </div>
  );
}
