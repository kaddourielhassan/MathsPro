'use client';

import { useStore } from '@/lib/store';
import { Moon, Sun, Users, ArrowLeft, Brain } from 'lucide-react';
import Link from 'next/link';

export default function Navigation() {
  const { currentProfileId, settings, role, toggleDarkMode, toggleDyslexiaMode, setCurrentProfile } = useStore();

  return (
    <nav className="m-4 flex items-center justify-between bg-white dark:bg-slate-800 rounded-3xl p-4 shadow-sm border-b-4 border-orange-200 dark:border-orange-900 relative z-50">
      <Link href="/" className="flex items-center gap-4">
        <div className="w-12 h-12 bg-orange-500 rounded-2xl flex items-center justify-center text-white font-bold text-2xl shadow-lg">
          M+
        </div>
        <div>
          <h1 className="text-2xl font-black tracking-tight text-orange-600 dark:text-orange-400">MathsPro</h1>
          <p className="text-xs font-bold uppercase text-slate-400 tracking-wider">Lycée Pro</p>
        </div>
      </Link>

      <div className="flex items-center gap-2 sm:gap-6">
        <div className="hidden md:flex items-center gap-2 bg-red-100 text-red-600 px-4 py-2 rounded-full border border-red-200 dark:bg-red-900/30 dark:border-red-800/50">
          <span className="text-xl">🚫</span>
          <span className="font-bold text-sm uppercase">Calculatrice Interdite</span>
        </div>
        <div className="hidden md:block h-12 w-px bg-slate-200 dark:bg-slate-700"></div>

        {currentProfileId && (
          <Link href="/dashboard" className="px-4 py-2 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 rounded-xl text-sm font-bold uppercase tracking-wider hover:bg-emerald-200 transition-colors flex items-center gap-2">
            <Brain size={18} />
            <span className="hidden sm:inline">Tableau de Bord</span>
          </Link>
        )}
        
        {role === 'teacher' && (
          <Link href="/teacher" className="px-4 py-2 bg-orange-100 dark:bg-orange-900/50 text-orange-700 dark:text-orange-300 rounded-xl text-sm font-bold uppercase tracking-wider hover:bg-orange-200 transition-colors flex items-center gap-2">
            <Users size={18} />
            <span className="hidden sm:inline">Espace Prof</span>
          </Link>
        )}

        <div className="flex bg-slate-100 dark:bg-slate-700 rounded-xl p-1">
          <button 
            onClick={toggleDarkMode}
            className="p-2 rounded-lg hover:bg-white dark:hover:bg-slate-600 transition"
            title="Mode sombre"
          >
            {settings.darkMode ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <button 
            onClick={toggleDyslexiaMode}
            className={`p-2 rounded-lg transition font-bold text-sm ${settings.dyslexiaMode ? 'bg-white dark:bg-slate-600 text-orange-600' : 'hover:bg-white dark:hover:bg-slate-600'}`}
            title="Mode Dyslexie"
          >
            DYS
          </button>
        </div>

        {currentProfileId && (
          <button 
            onClick={() => setCurrentProfile(null)}
            className="text-xs font-bold uppercase tracking-wider text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition"
          >
            Quitter
          </button>
        )}
      </div>
    </nav>
  );
}
